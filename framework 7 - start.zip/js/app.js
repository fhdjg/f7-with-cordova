var app = new Framework7({
  // App root element
  root: '#app',
  // App Name
  name: 'My App',
  // App id
  id: 'com.myapp.test',
  // Enable swipe panel
  panel: {
    swipe: 'left',
  },
  view: {
    pushState: true,
  },

  // Add default routes, dapat diatur di routes.js
  routes: routes,
  on: {
    pageInit: function(){
    }
  }
});
var mainView = app.views.create('.view-main');